// Copyright 2024 bhipp
#ifndef CHECK_ARRAYS_MATCH_H_
#define CHECK_ARRAYS_MATCH_H_

bool ArraysMatch(const double array1[][10], const double array2[][10],
                 int rows);

void Print(const double num[][10], int num_rows);

#endif
